import xlrd
import pandas as pd
from numpy import mat
from sklearn.model_selection import train_test_split
from sklearn import tree


def dataSet(filename):
    """
    读取问题1excel数据
    :param filename: 文件名称
    :return: 数据集
    """
    data = xlrd.open_workbook(filename)
    table = data.sheet_by_index(0)
    dataSet1 = []
    dataSet2 = []
    cols = [2, 5, 8, 9, 10, 13, 14, 15, 18]
    for i in range(1, 124):
        temp = []
        for col in cols:
            temp.append(table.row(i)[col].value)
        dataSet2.append(temp[1:])
        dataSet1.append(table.row(i)[2].value)
    return dataSet1, dataSet2


def dataSet2(filename):
    """
    读取问题2excel数据
    :param filename:文件名
    :return: 数据集
    """
    data = xlrd.open_workbook(filename)
    table = data.sheet_by_index(0)
    cols = [4, 7, 8, 9, 12, 13, 14, 17]
    dataSet = []
    for i in range(1, 303):
        temp = []
        for col in cols:
            temp.append(table.row(i)[col].value)
        dataSet.append(temp)
    return dataSet


def dataSet3(filename):
    """
    读取问题1excel数据
    :param filename: 文件名称
    :return: 数据集
    """
    data = xlrd.open_workbook(filename)
    table = data.sheet_by_index(0)
    dataSet1 = []
    dataSet2 = []
    cols = [2, 5, 8, 9, 10, 13, 14, 15, 18, 19]
    for i in range(1, 124):
        temp = []
        for col in cols:
            temp.append(table.row(i)[col].value)
        dataSet2.append(temp[0:-1])
        dataSet1.append(table.row(i)[19].value)
    return dataSet1, dataSet2


target, data = dataSet('问题1数据处理.xlsx')  # 预测信誉评级数据
test = dataSet2('问题2数据处理.xlsx')  # 待预测数据
data = mat(data)
target_final, data_final = dataSet3('问题1数据处理.xlsx')  # 预测是否违约数据
data_final = mat(data_final)
pd.concat([pd.DataFrame(data), pd.DataFrame(target)], axis=1)
pd.concat([pd.DataFrame(data_final), pd.DataFrame(target_final)], axis=1)

# 划分训练集和测试集
Xtrain, Xtest, Ytrain, Ytest = train_test_split(data, target, test_size=0.2)
Xtrain_final, Xtest_final, Ytrain_final, Ytest_final = train_test_split(data_final, target_final, test_size=0.2)

# 训练决策树模型
clf = tree.DecisionTreeClassifier()
clf1 = clf.fit(Xtrain, Ytrain)
# 先预测302家企业的信誉评级
predicts = clf1.predict(test)
for i in range(302):
    test[i].append(predicts[i])
    temp = test[i][0]
    test[i][0] = test[i][-1]
    test[i][-1] = temp
# 训练决策树模型
clf2 = clf.fit(Xtrain_final, Ytrain_final)
# 预测302家企业违约情况
result = clf2.predict(test)
print(result)
