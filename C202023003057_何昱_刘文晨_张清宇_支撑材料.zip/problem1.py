import xlrd
from numpy import mat
from sklearn import tree
from sklearn.model_selection import train_test_split
from sklearn.model_selection import learning_curve
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


def dataSet(filename):
    """
    读取excel数据
    :param filename: 文件名称
    :return: 数据集
    """
    data = xlrd.open_workbook(filename)
    table = data.sheet_by_index(0)
    dataSet1 = []
    dataSet2 = []
    cols = [2, 5, 8, 9, 10, 13, 14, 15, 18, 19]
    for i in range(1, 124):
        temp = []
        for col in cols:
            temp.append(table.row(i)[col].value)
        dataSet2.append(temp[0:-1])
        dataSet1.append(table.row(i)[19].value)
    return dataSet1, dataSet2


# 数据处理阶段
target, data = dataSet('问题1数据处理.xlsx')
data = mat(data)
feature_names = ['rating', 'eff', 'neg', 'sum_in', 'sum_out', 'sum_tax', 'max_in', 'max_out', 'max_tax']
target_names = ['0', '1']
pd.concat([pd.DataFrame(data), pd.DataFrame(target)], axis=1)

# 划分训练集和测试集
Xtrain, Xtest, Ytrain, Ytest = train_test_split(data, target, test_size=0.2)

# 训练决策树模型
clf = tree.DecisionTreeClassifier()
clf = clf.fit(Xtrain, Ytrain)
# 决策树可视化
with open('result.txt', 'w', encoding='utf-8') as f:
    f = tree.export_graphviz(clf, out_file=f, feature_names=feature_names, class_names=target_names)
score = clf.score(Xtest, Ytest)  # 使用测试集进行正确性检验
print('accuracy:', score)
# 使用决策树预测
predict = clf.predict(data)
print(predict)

# 模型调优
train_sizes, train_score, test_score = learning_curve(clf, data, target,
                                                      train_sizes=[0.1, 0.2, 0.4, 0.6, 0.8], cv=10,
                                                      scoring='accuracy')
train_accuracy = np.mean(train_score, axis=1)
test_accuracy = np.mean(test_score, axis=1)
plt.plot(train_sizes, train_accuracy, '*-', color='b', label='training score')
plt.plot(train_sizes, test_accuracy, 'o-', color='r', label='cross-validation score')
plt.title('learning curves(Decision Tree)')
plt.legend(loc='best')
plt.xlabel('traing size')
plt.ylabel('score')
plt.grid()
plt.show()
