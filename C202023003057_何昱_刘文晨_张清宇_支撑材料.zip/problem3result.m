A=[1.05;1.10;1.15]*[1.028 1.102 0.968 1.112 1.175 1.178]
for m=1:302
    i=I(m)
    j=J(m)
    RNEW(m)=R(m)*A(i,j)
end
RNEW=RNEW'